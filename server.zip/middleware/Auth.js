//user authentication
const Auth = (req,res,next) =>{
//middlewares has the access to req,res of http requests
//so on the way,we can change them and then allow to the api interaction to the database
console.log(req);

// next()
}
module.exports={Auth}